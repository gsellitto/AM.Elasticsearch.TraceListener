﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static  void Main(string[] args)
        {

            System.Diagnostics.Trace.Listeners.Add(
                new AM.Elasticsearch.TraceListener.ElasticSearchTraceListener("EPCAPI","https://localhost:9300", "elastic", "3MSv1CqDB5JhbHke7Tg_"));

            System.Diagnostics.Trace.TraceError("ook");
            System.Diagnostics.Trace.TraceError("ook");
            System.Diagnostics.Trace.Flush();
            System.Diagnostics.Trace.TraceError("ook");
            System.Diagnostics.Trace.TraceError("ook");
            System.Diagnostics.Trace.TraceError("ook");

            Task.Delay(200000).Wait();

        }
    }
}
